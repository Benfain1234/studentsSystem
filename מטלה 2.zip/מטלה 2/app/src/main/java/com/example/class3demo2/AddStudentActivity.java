package com.example.class3demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.example.class3demo2.model.Model;
import com.example.class3demo2.model.Student;

import java.util.Random;

public class AddStudentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);

        EditText nameEt = findViewById(R.id.addstudent_name_et);
        EditText idEt = findViewById(R.id.addstudent_id_et);
        EditText phoneEt = findViewById(R.id.editPhoneNumber);
        EditText address = findViewById(R.id.editAddress);
        TextView messageTv = findViewById(R.id.addstudent_message);
        Button saveBtn = findViewById(R.id.addstudent_save_btn);
        Button cancelBtn = findViewById(R.id.addstudent_cancell_btn);

        saveBtn.setOnClickListener(view -> {
            String name = nameEt.getText().toString();
            messageTv.setText(name);
            int size = Model.instance().getAllStudents().size();
            String sizeString = Integer.toString(size);
            Random random =  new Random();
            int rand = random.nextInt(6);
            Student student= new Student(name,idEt.getText().toString(),rand,phoneEt.getText().toString(),address.getText().toString());
            Model.instance().getAllStudents().add(student);
            finish();
        });

        cancelBtn.setOnClickListener(view -> finish());
    }
}