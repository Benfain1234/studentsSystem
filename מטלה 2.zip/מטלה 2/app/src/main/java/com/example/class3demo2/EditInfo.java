package com.example.class3demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import com.example.class3demo2.model.Model;
import com.example.class3demo2.model.Student;

public class EditInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_info);
        Student student = Model.instance().getSelected();
        TextView editName = findViewById(R.id.editName);
        TextView editId = findViewById(R.id.editId);
        TextView editPhone = findViewById(R.id.editPhone);
        TextView editAddress = findViewById(R.id.editAdd);
        editName.setText(student.name);
        editId.setText(student.id);
        editPhone.setText(student.phoneNum);
        editAddress.setText(student.address);
        Button finishEdit = findViewById(R.id.finishEdit);
        finishEdit.setOnClickListener(view -> {
             student.setName(editName.getText().toString());
             student.setId(editId.getText().toString());
             student.setPhoneNum(editPhone.getText().toString());
             student.setAddress(editAddress.getText().toString());
            finish();
        });
        Button cancelButton = findViewById(R.id.CancelEdit);
        cancelButton.setOnClickListener(view -> {finish();});
        Button deleteButton = findViewById(R.id.deleteStudent);
        deleteButton.setOnClickListener(view -> {
            Model.instance().getAllStudents().remove(student);
            Intent i = new Intent(EditInfo.this,MainActivity.class);
            startActivity(i);
        });


    }


}