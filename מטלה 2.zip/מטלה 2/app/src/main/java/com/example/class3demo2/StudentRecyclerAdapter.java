package com.example.class3demo2;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.class3demo2.model.Model;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.class3demo2.model.Student;

import java.util.List;


class StudentViewHolder extends RecyclerView.ViewHolder{
    TextView nameTv;
    TextView idTv;
    ImageView avatar;
    Button editButton;
    List<Student> data;
    public StudentViewHolder(@NonNull View itemView, StudentRecyclerAdapter.OnItemClickListener listener, List<Student> data) {
        super(itemView);
        this.data = data;
        nameTv = itemView.findViewById(R.id.studentlistrow_name_tv);
        idTv = itemView.findViewById(R.id.studentlistrow_id_tv);
        avatar = itemView.findViewById(R.id.studentlistrow_avatar_img);
        editButton = itemView.findViewById(R.id.edit_button);
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Model.instance().setSelected(getAdapterPosition());
                Log.d("TAG", Model.instance().getSelected().name + "Row was selected " );
              Intent i = new Intent( view.getContext(), Student_Info.class);
               i.putExtra("Name",Model.instance().getSelected().name);
                i.putExtra("Id",Model.instance().getSelected().id);
                i.putExtra("Avatar",Model.instance().getSelected().avatarUrl);
                i.putExtra("phone",Model.instance().getSelected().phoneNum);
                i.putExtra("address",Model.instance().getSelected().address);
                view.getContext().startActivity(i);


            }
        });
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = getAdapterPosition();
                listener.onItemClick(pos);
            }
        });
    }

    public void bind(Student st, int pos) {
        nameTv.setText("Name: "+st.name);
        idTv.setText("ID: "+ st.id);
        switch(st.avatarUrl) {
            case 1:
                avatar.setImageResource(R.drawable.avatar1);
                break;
            case 2:
                avatar.setImageResource(R.drawable.avatar2);
                break;
            case 3:
                avatar.setImageResource(R.drawable.avatar3);
                break;
            case 4:
                avatar.setImageResource(R.drawable.avatar4);
                break;
            case 5:
                avatar.setImageResource(R.drawable.avatar5);
                break;
            case 6:
                avatar.setImageResource(R.drawable.avatar6);
                break;
            default:
                 break;
        }


    }
}

public class StudentRecyclerAdapter extends RecyclerView.Adapter<StudentViewHolder>{
    OnItemClickListener listener;
    public static interface OnItemClickListener{
        void onItemClick(int pos);
    }

    LayoutInflater inflater;
    List<Student> data;
    Student selected;
    public StudentRecyclerAdapter(LayoutInflater inflater, List<Student> data, Student selected){
        this.inflater = inflater;
        this.data = data;
        this.selected = selected;
    }

    void setOnItemClickListener(OnItemClickListener listener){
        this.listener = listener;
    }
    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.student_list_row,parent,false);
        return new StudentViewHolder(view,listener, data);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        Student st = data.get(position);
        holder.bind(st,position);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

}

