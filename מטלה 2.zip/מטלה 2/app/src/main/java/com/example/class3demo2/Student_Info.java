package com.example.class3demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.class3demo2.model.Model;
import com.example.class3demo2.model.Student;

public class Student_Info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_info);
        Intent intent = getIntent();
        Student student = Model.instance().getSelected();
        TextView nameInfo =  findViewById(R.id.infoName);
        nameInfo.setText(student.name);
        TextView idInfo = findViewById(R.id.infoId);
        idInfo.setText(student.id);
        setImg(student);
        TextView phoneInfo = findViewById(R.id.infoPhone);
        phoneInfo.setText(student.phoneNum);
        TextView address = findViewById(R.id.infoAddress);
        address.setText(student.address);
        Button backButton = findViewById(R.id.backButton);
        Button editButton =  findViewById(R.id.editButton);
        backButton.setOnClickListener(view -> {
            Intent i = new Intent(Student_Info.this,MainActivity.class);
            startActivity(i);
        }  );

        editButton.setOnClickListener(view -> {
            Intent i = new Intent(Student_Info.this,EditInfo.class);
            startActivity(i);
        });


    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("TAG", "start");
        Student student = Model.instance().getSelected();
        TextView nameInfo =  findViewById(R.id.infoName);
        nameInfo.setText(student.name);
        TextView idInfo = findViewById(R.id.infoId);
        idInfo.setText(student.id);
        TextView phoneInfo = findViewById(R.id.infoPhone);
        phoneInfo.setText(student.phoneNum);
        TextView address = findViewById(R.id.infoAddress);
        address.setText(student.address);
    }
   private void setImg(Student st){
       ImageView  img = findViewById(R.id.Avatar_Img);
       switch(st.avatarUrl) {
           case 1:
               img.setImageResource(R.drawable.avatar1);
               break;
           case 2:
               img.setImageResource(R.drawable.avatar2);
               break;
           case 3:
               img.setImageResource(R.drawable.avatar3);
               break;
           case 4:
               img.setImageResource(R.drawable.avatar4);
               break;
           case 5:
               img.setImageResource(R.drawable.avatar5);
               break;
           case 6:
               img.setImageResource(R.drawable.avatar6);
               break;
           default:
               break;
       }
   }
}