package com.example.class3demo2.model;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class Model {
    private static final Model _instance = new Model();

    public static Model instance(){
        return _instance;
    }
    private Model(){
        int j=1;
        for(int i=0;i<20;i++){
            if (j==7)
            j = 1;
            Random random =  new Random();
            int rand = random.nextInt(10000000);
            String randNum = Integer.toString(rand);
            addStudent(new Student("name " + i,""+i,j,"052"+randNum,"Rishon-Lezion"));
            j++;
        }
    }

    List<Student> data = new LinkedList<>();
    Student selected = null;
    public List<Student> getAllStudents(){
        return data;
    }

    public Student getSelected(){
        return selected;
    }
    public void setSelected(int pos){
        this.selected = data.get(pos);
    }

    public void addStudent(Student st){
        data.add(st);
    }


}
