package com.example.class3demo2.model;

public class Student {
    public String name;
    public String id;
    public int avatarUrl;
    public String phoneNum;
    public String address;

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Student(String name, String id, int avatarUrl, String phoneNum, String address) {
        this.name = name;
        this.id = id;
        this.avatarUrl = avatarUrl;
         this.phoneNum = phoneNum;
         this.address = address;
    }
}
